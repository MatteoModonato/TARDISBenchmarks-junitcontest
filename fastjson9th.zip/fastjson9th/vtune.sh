export AMPLXE_EXPERIMENTAL=1
/Users/wenshao/Install/vtune/amplxe-cl -collect hotspots java -classpath target/classes/:target/test-classes/ com.alibaba.json.test.benchmark.BenchmarkMain
