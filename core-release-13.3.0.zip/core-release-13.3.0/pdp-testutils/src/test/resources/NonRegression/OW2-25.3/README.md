PDP initialization must fail with IllegalArgumentException when using unknown/unsupported higher-order Function as Apply function
