PDP initialization must fail with IllegalArgumentException when using unknown/unsupported first-order Function as Apply function
