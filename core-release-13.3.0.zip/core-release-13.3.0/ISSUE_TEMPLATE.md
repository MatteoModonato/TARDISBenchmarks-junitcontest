# Software version (AuthzForce Core)

# Platform JRE

# Platform OS

# Error stack trace or logs (if any)
*If in doubt include the whole thing; often exceptions get wrapped in other exceptions and the exception right near the bottom explains the actual error, not the first few lines at the top.*

# Your code and/or AuthzForce-specific configuration file(s)

