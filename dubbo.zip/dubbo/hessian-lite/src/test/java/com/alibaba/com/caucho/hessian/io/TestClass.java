package com.alibaba.com.caucho.hessian.io;

import java.io.Serializable;

public class TestClass implements Serializable {
}
