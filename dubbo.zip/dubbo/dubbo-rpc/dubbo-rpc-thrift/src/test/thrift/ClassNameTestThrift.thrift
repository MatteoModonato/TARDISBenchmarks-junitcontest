service ClassNameTestThrift {
    string echo(1:required string arg);
}