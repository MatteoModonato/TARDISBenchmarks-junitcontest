sh servercommon.sh "../lib" "com.alibaba.dubbo.rpc.benchmark.RpcBenchmarkServer" "rpcserver.log.dubbo"
