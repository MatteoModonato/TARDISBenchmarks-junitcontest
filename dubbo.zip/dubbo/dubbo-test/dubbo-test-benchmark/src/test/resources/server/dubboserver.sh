sh servercommon.sh "../lib" "com.alibaba.dubbo.rpc.benchmark.BenchmarkServer" "server.log.dubbo"
