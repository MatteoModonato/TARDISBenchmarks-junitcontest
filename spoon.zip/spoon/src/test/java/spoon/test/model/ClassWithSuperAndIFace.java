package spoon.test.model;

import spoon.test.model.testclasses.InterfaceWrithFields;

public class ClassWithSuperAndIFace extends Foo implements InterfaceWrithFields
{
	String classField;

	public ClassWithSuperAndIFace()
	{
		// TODO Auto-generated constructor stub
	}

}
