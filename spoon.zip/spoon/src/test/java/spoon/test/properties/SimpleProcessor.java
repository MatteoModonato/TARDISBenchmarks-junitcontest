/**
 * spoon.test.properties.SimpleProcessor.java
 * <p>
 * Copyright (c) 2007-2015 UShareSoft SAS, All rights reserved
 *
 * @author UShareSoft
 */
package spoon.test.properties;

import spoon.processing.AbstractProcessor;
import spoon.reflect.declaration.CtMethod;

public class SimpleProcessor extends AbstractProcessor<CtMethod<?>> {

    @Override
    public void process(CtMethod<?> element) {

    }
}
