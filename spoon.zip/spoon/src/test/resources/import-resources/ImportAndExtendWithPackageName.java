import antlr.*;

public class ImportAndExtendWithPackageName extends antlr.LLkParser {
    public static void main(final String[] args) {}
}
