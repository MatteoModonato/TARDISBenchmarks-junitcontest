package fr.inria;

public class A {
}