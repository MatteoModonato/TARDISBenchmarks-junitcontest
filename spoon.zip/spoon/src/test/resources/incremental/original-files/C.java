public class C {

	int val;
}
