public class B {

	void func(C c) {
		c.val = 42;
	}
}
