package spoontest;

public class Foo implements IFoo
{
	public Foo()
	{
	}
}
