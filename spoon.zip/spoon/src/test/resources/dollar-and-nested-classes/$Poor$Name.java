public class $Poor$Name {
    public Choice lookingForTroubles() {
        return new Choice();
    }
    class Choice {
        public Choice() { }
    }
}