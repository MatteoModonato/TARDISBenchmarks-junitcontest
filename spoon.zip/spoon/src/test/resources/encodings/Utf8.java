public class Utf8 {
    String s1 = "Привет мир";
    String s2 = "ГДЕ"
}
