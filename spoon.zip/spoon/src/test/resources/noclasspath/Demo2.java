
public class Demo2 implements example.FooBar<?, ? extends Tacos<?>>.Bar<?, ? extends Tacos<?>> {

}