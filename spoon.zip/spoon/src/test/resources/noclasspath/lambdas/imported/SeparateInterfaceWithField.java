package imported;

public interface SeparateInterfaceWithField {
    String fieldInSeparateInterface = "spoon";
}
