import com.google.common.base.Joiner;
import com.google.common.base.Function;

public class Demo extends Function<String, String> implements Function<String, String> {

    public static void main(String[] args) {
        Joiner.on();
    }
}