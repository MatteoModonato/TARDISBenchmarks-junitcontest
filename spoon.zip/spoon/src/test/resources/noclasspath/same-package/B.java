package spoon.test.same;

public class B {

    public String getName() {
        return "This is B.";
    }
}
