
import com.awesome.Burritos;

public class Panini {
	public Burritos m() {
		return null;
	}
}