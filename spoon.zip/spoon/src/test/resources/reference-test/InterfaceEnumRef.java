
public class InterfaceEnumRef {

	void testEnumFromInterface() {
		InterfaceWithEnum.Colors x;
		x = InterfaceWithEnum.Colors.Black;

		InterfaceWithEnumJar.Colors y;
		y = InterfaceWithEnumJar.Colors.Black;
	}
}
