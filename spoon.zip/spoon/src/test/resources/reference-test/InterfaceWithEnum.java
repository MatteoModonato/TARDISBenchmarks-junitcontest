
public interface InterfaceWithEnum {

	public static enum Colors { Red, Black, White };
	String someMethod();
}
