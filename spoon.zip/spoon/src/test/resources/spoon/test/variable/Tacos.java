package spoon.test.variable;

public class Tacos {
	public void testExtendedStringLiteral() throws Exception {
		new Abcd() {
			public void m() {
				startTime = System.currentTimeMillis();
			}
		};
	}
}
