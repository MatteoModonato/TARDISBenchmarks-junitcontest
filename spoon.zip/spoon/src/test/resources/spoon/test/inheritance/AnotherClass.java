package org.acme;

import fr.acme.MyClass;

public class AnotherClass {
	MyClass field;
}