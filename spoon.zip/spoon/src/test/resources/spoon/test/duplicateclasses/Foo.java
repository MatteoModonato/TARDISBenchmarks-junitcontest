package spoon.test.exceptions;

//also defined in Bar.java
class Foo {} 