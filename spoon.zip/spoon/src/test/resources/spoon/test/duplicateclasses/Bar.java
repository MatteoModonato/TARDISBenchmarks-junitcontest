package spoon.test.exceptions;
public class Bar{}

// also defined in Foo.java
class Foo {} 