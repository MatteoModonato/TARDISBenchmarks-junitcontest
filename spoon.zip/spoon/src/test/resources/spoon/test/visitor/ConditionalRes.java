public class ConditionalRes {

	byte [] b = new byte [] { true ? 1 : 2};

}