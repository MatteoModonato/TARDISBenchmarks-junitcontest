public class Assignments {

	public void func(int x) {
		x = 42;
		x += 42;

		x >>= 42;
		x = 42;

		x -= 42;
		x += 42;

		x = 42;
		x = 100;

		x = 42;
		x = 42;
	}
}
