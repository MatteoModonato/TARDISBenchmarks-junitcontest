// for API test
public class Foo{}
class Bar{}
