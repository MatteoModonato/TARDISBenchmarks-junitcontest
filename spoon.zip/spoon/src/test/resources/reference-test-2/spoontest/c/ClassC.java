package spoontest.c;

public class ClassC {
	public String name(Object o) {
		return o.getClass().getName();
	}
}
