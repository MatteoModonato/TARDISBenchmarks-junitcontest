package compilation;

/**
 * Created by thomas on 28/10/16.
 */
public interface IBar {
	int m();
}
