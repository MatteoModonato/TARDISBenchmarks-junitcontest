package spoon.test.imports.testclasses;
/**
 * Created by urli on 16/10/2017.
 */
public class TestWithGenerics {
    public spoon.test.imports.testclasses.withgenerics.Target<Object, Object> myfields;
}
