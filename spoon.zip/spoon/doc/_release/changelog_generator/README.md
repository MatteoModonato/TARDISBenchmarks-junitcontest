# Changelog Generator

## Usage
```
cd doc/_release/changelog_generator
npm install
node changelog.js <previous-spoon-version>
```
