package com.derbysoft.spitfire.fastjson.dto;

public enum PaymentType {
    POA,
    PREPAY
}
