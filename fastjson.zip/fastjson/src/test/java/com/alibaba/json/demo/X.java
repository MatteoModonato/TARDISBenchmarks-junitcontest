package com.alibaba.json.demo;


public class X {

}
