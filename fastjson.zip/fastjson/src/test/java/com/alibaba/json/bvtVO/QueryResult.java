package com.alibaba.json.bvtVO;

public class QueryResult {
    private PayDO pay;

    public void setPay(PayDO pay) {
        this.pay = pay;
    }

    public PayDO getPay() {
        return pay;
    }
}
